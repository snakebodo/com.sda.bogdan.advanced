package com.sda.bogdan.advanced.InterFace.ex2;

import java.time.LocalDateTime;

public interface DateTimeClient {
    void sendCurrentDateAndTime(LocalDateTime localDateTime);
}
