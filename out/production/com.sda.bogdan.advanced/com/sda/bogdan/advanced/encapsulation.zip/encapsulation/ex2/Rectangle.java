package com.sda.bogdan.advanced.encapsulation.ex2;

public class Rectangle extends Shape{

    public Rectangle(double area, double perimeter) {
        super(area, perimeter);
    }
}
